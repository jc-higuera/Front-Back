import React from "react";
import ReactDOM from "react-dom";

import Jobs from "./components/Jobs";
import Create from "./components/JobForm";

ReactDOM.render(
  <div>
    <Jobs />
    <Create />
  </div>,
  document.getElementById("root")
);