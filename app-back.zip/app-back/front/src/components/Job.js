import React from 'react';



export default class Job extends React.Component {
  /* state = {
    "name": "Asesor comercial de hipermercado",
    "company": "Schneider Electric", 
    "salary": "$4.5 a $5.5 millones",
    "city":  "Bogotá, Colombia"
  }
  
  renderOffer(){
    return (
      <div>
        <h2>{this.state.name}</h2>
        <h3>{this.state.company}</h3>
        <h4>{this.state.salary}</h4>
        <h5>{this.state.city}</h5>
      </div>
    );
  } */

  state = {
    "offer": this.props.offer
  };
  
  //
  
  renderOffer() {
    return (
      <div>
        <h2>{this.state.offer.name}</h2>
        <h3>{this.state.offer.company}</h3>
        <h4>{this.state.offer.salary}</h4>
        <h5>{this.state.offer.city}</h5>
      </div>
    );
  }
  
  render() {
    return (
      <div>
        {this.renderOffer()}
      </div>
    );
  }
} 
