import React, { Component } from "react";
import axios from "axios";

class Create extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      company: "",
      salary: "",
      city: ""
    };
  }

  handleInputChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  handleSubmit = (e) => {
    e.preventDefault();

    const { name, company, salary, city } = this.state;

    const job = {
      name,
      company,
      salary,
      city
    };

    axios
      .post("http://localhost:3001/offers", job)
      .then(() => console.log("Job Created"))
      .catch((err) => {
        console.error(err);
      });
  };

  render() {
    return (
      <div>
        <br />
        <div className="container">
          <form onSubmit={this.handleSubmit}>
            <div>
              <label htmlFor="name">Name</label>
              <input type="text" id="name" name="name" onChange={this.handleInputChange}/>
            </div>

            <div>
              <label htmlFor="company">Company</label>
              <input type="text" id="company" name="company" onChange={this.handleInputChange}/>
            </div>

            <div>
              <label htmlFor="salary">Salary</label>
              <input type="text" id="salary" name="salary" onChange={this.handleInputChange}/>
            </div>
            <div>
              <label htmlFor="city">City</label>
              <input type="text" id="city" name="city" onChange={this.handleInputChange}/>
            </div>
            <div style={{ width: "30%" }}>
              <button className="btn btn-success" type="submit">
                Create
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Create;