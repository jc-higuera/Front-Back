import React from 'react';

import useForm from "./customHooks";

function Add() {
  const { handleSubmit } = useForm();
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            name="name"
          />
        </div>

        <div>
          <label htmlFor="company">Company</label>
          <input
            type="text"
            id="company"
            name="company"
          />
        </div>

        <div>
          <label htmlFor="salary">Salary</label>
          <input
            type="text"
            id="salary"
            name="salary"
          />
        </div>
        <div>
          <label htmlFor="city">City</label>
          <input
            type="text"
            id="city"
            name="city"
          />
        </div>
        <button type="submit">Add</button>
      </form>
    </div>
  );
}

export default Add;